$(document).ready(function() {

	var slider = 0;
	$.Slider = function(toplam){
		$("#headerSlider ul#buton li").removeClass("aktif");
		$("#headerSlider ul#resim li").hide();
		if (slider < toplam-1) {
			slider++;
			$("#headerSlider ul#buton li:eq("+slider+")").addClass('aktif');
			$("#slider ul#resim li:eq("+slider+")").fadeIn('slow');
			return false
		}else{

			$("#headerSlider ul#buton li:first").addClass('aktif');
			$("#headerSlider ul#resim li:first").fadeIn('fast');

			slider = 0;

		}
	}

	var toplamLi = $("#headerSlider ul#resim li").length;
	var interval = setInterval('$.Slider('+toplamLi+')',2000);
	$("#headerSlider").hover(function(){
		clearInterval(interval);
	}, function(){
		interval = setInterval('$.Slider('+toplamLi+')',2000);
	});





	$("#headerSlider ul#buton li:first").addClass('aktif');
	$("#headerSlider ul#resim li").hide();
	$("#headerSlider ul#resim li").show();

	$("#headerSlider ul#buton li").click(function() {
		var indis=$(this).index();
			$("#headerSlider ul#buton li").removeClass("aktif");
			$(this).addClass('aktif');
			$("#headerSlider ul#resim li").hide();
			$("#headerSlider ul#resim li:eq("+indis+")").fadeIn('fast');
			slider = indis;
			return false
	});
});