jQuery(document).ready(function($) {

	

	var uzunluk = $(".slider ul li").length;
	uzunluk--; 

	var sira=0; 

	$('.slider ul li:not(:eq('+sira+'))').hide();


	// ileri butonu


	$('.btnIleri').click(function(){
		$('.slider ul li').fadeOut(); 
		if (sira < uzunluk) {
			sira++;
			$('.slider ul li:eq(' +sira+ ')').fadeIn();
		}
		else{
			sira=0;
			$('.slider ul li:eq(' +sira+ ')').fadeIn();
		};
	});

	// geri butonu

	$('.btnGeri').click(function() {
		$('.slider ul li').fadeOut(); //Yine herşeyi gizledik.
		if (sira > 0) {
			sira--;
			$('.slider ul li:eq(' +sira +')').fadeIn();
		}
		else{
			sira=uzunluk;
			$('.slider ul li:eq(' +sira +')').fadeIn();
		};

	});


});