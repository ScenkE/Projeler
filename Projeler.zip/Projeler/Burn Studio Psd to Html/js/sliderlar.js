$(document).ready(function() {

	var slider = 0;
	$.Slider = function(toplam){
		$("#slider ul#buton li").removeClass("aktif");
		$("#slider ul#resim li").hide();
		if (slider < toplam-1) {
			slider++;
			$("#slider ul#buton li:eq("+slider+")").addClass('aktif');
			$("#slider ul#resim li:eq("+slider+")").fadeIn('slow');
			return false
		}else{

			$("#slider ul#buton li:first").addClass('aktif');
			$("#slider ul#resim li:first").fadeIn('fast');

			slider = 0;

		}
	}

	var toplamLi = $("#slider ul#resim li").length;
	var interval = setInterval('$.Slider('+toplamLi+')',3000);
	$("#slider").hover(function(){
		clearInterval(interval);
	}, function(){
		interval = setInterval('$.Slider('+toplamLi+')',3000);
	});





	$("#slider ul#buton li:first").addClass('aktif');
	$("#slider ul#resim li").hide();
	$("#slider ul#resim li").show();

	$("#slider ul#buton li").click(function() {
		var indis=$(this).index();
			$("#slider ul#buton li").removeClass("aktif");
			$(this).addClass('aktif');
			$("#slider ul#resim li").hide();
			$("#slider ul#resim li:eq("+indis+")").fadeIn('fast');
			slider = indis;
			return false
	});








	var uzunluk = $(".yazi_slider ul li").length;
	uzunluk--; 

	var sira=0; 

	$('.yazi_slider ul li:not(:eq('+sira+'))').hide();


	// ileri butonu


	$('.btnIleri').click(function(){
		$('.yazi_slider ul li').fadeOut(); 
		if (sira < uzunluk) {
			sira++;
			$('.yazi_slider ul li:eq(' +sira+ ')').fadeIn();
		}
		else{
			sira=0;
			$('.yazi_slider ul li:eq(' +sira+ ')').fadeIn();
		};
	});

	// geri butonu

	$('.btnGeri').click(function() {
		$('.yazi_slider ul li').fadeOut();
		if (sira > 0) {
			sira--;
			$('.yazi_slider ul li:eq(' +sira +')').fadeIn();
		}
		else{
			sira=uzunluk;
			$('.yazi_slider ul li:eq(' +sira +')').fadeIn();
		};

	});




});