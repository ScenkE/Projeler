$(function(){

var sure = 2000;
var toplamLi = $(".sliderIcerik ul li").length;
var liWidth = 500;
var toplamWidth = liWidth * toplamLi;
var liDeger = 0;
$(".sliderIcerik ul").css("width", toplamWidth + "px");

$("a.sonraki").click(function(){

	if(liDeger < toplamLi - 1){
		liDeger++;
		yeniWidth = liWidth * liDeger;
		$(".sliderIcerik ul").animate({marginLeft: "-" + yeniWidth + "px"}, 500);
	} 

	return false;
	})






$("a.onceki").click(function(){ 

	if(liDeger > 0){ 
		liDeger--;
		yeniWidth = liWidth * liDeger;
		$(".sliderIcerik ul").animate({marginLeft: "-" + yeniWidth + "px"}, 500);
	}

	return false;
	})





	/* Otomatik Dönme */



	$.Slider = function(){ 
		if (liDeger < toplamLi - 1){
			liDeger++; 
			yeniWidth = liWidth * liDeger;
			$(".sliderIcerik ul").animate({marginLeft: "-" + yeniWidth + "px"}, 500);
		} else{ 
			liDeger = 0;
			$(".sliderIcerik ul").animate({marginLeft: "0"}, 500);

		}
	}




	var don = setInterval("$.Slider()", sure); 

	$("#sliderKapsayicisi").hover(function(){
		clearInterval(don);
	}, function(){
		don = setInterval("$.Slider()", sure);
	})



});
