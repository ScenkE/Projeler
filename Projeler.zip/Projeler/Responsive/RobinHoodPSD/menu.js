
$(function(){
	var a = 0;
	$('.menuAcKapat').click(function(){
		if ( a == 0 ){
			a++;
		} else {
			a = 0;
		}
		$('ul.ac').slideToggle(500);
	});
});